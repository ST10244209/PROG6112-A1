/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package prog6112a1question2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class BookTest {

    private Book book;

    @BeforeEach
    public void setUp() {
        book = new Book("Title1", "Author1", 2022);
    }

    @Test
    public void testGetTitle() {
        assertEquals("Title1", book.getTitle());
    }

    @Test
    public void testGetAuthor() {
        assertEquals("Author1", book.getAuthor());
    }

    @Test
    public void testGetYear() {
        assertEquals(2022, book.getYear());
    }

    @Test
    public void testToString() {
        String expectedOutput = "Title: Title1\nAuthor: Author1\nYear: 2022\n";
        assertEquals(expectedOutput, book.toString());
    }
}

