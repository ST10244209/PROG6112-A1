/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package prog6112a1question2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.io.InputStream;
import java.util.Scanner;

public class LibraryManagementAppTest {

    private LibraryManagementApp libraryApp;
    private InputStream originalIn;
    private PrintStream originalOut;
    private ByteArrayOutputStream outputStream;

    @BeforeEach
    public void setUp() {
        libraryApp = new LibraryManagementApp();
        originalIn = System.in;
        originalOut = System.out;
        outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
    }

    @AfterEach
    public void tearDown() {
        System.setIn(originalIn);
        System.setOut(originalOut);
    }

    @Test
    public void testAddBookAndViewCatalog() {
        // Prepare user input for adding a book and viewing the catalog
        String userInput = "1\nTitle1\nAuthor1\n2022\n2\n3\n";
        System.setIn(new java.io.ByteArrayInputStream(userInput.getBytes()));

        libraryApp.main(new String[0]); // Run the library app

        String expectedOutput = "Welcome to the Library Management System\n" +
                "\nMenu:\n" +
                "1. Add a Book\n" +
                "2. View Library Catalog\n" +
                "3. Exit\n" +
                "Enter your choice: Enter the book title: Enter the author's name: Enter the publication year: " +
                "Book added to the library.\n" +
                "\nMenu:\n" +
                "1. Add a Book\n" +
                "2. View Library Catalog\n" +
                "3. Exit\n" +
                "Enter your choice: Library Catalog:\n" +
                "Book 1:\nTitle: Title1\nAuthor: Author1\nYear: 2022\n\n" +
                "Menu:\n" +
                "1. Add a Book\n" +
                "2. View Library Catalog\n" +
                "3. Exit\n" +
                "Enter your choice: Exiting the Library Management System. Goodbye!\n";

        assertEquals(expectedOutput, outputStream.toString());
    }

    @Test
    public void testExitLibraryApp() {
        // Prepare user input for exiting the app
        String userInput = "3\n";
        System.setIn(new java.io.ByteArrayInputStream(userInput.getBytes()));

        libraryApp.main(new String[0]); // Run the library app

        String expectedOutput = "Welcome to the Library Management System\n" +
                "\nMenu:\n" +
                "1. Add a Book\n" +
                "2. View Library Catalog\n" +
                "3. Exit\n" +
                "Enter your choice: Exiting the Library Management System. Goodbye!\n";

        assertEquals(expectedOutput, outputStream.toString());
    }
}

