/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog6112.a1.question1;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import java.util.InputMismatchException;

class Student {
    private String studentID;
    private String studentName;
    private int age;
    private String email;
    private String course;

    // Constructor
    public Student(String studentID, String studentName, int age, String email, String course) {
        this.studentID = studentID;
        this.studentName = studentName;
        this.age = age;
        this.email = email;
        this.course = course;
    }

    // Getters
    public String getStudentID() {
        return studentID;
    }

    public String getStudentName() {
        return studentName;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getCourse() {
        return course;
    }

    // Override toString for printing student details
    @Override
    public String toString() {
        return "STUDENT ID: " + studentID +
                "\nSTUDENT NAME: " + studentName +
                "\nSTUDENT AGE: " + age +
                "\nSTUDENT EMAIL: " + email +
                "\nSTUDENT COURSE: " + course;
    }
}

public class StudentManagementApp {
    static ArrayList<Student> students = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        displayMenu();
    }

    private static void displayMenu() {
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        System.out.println("Enter 1 to launch menu or any other key to exit");
        System.out.println("\nPlease select one of the following menu items:");
        System.out.println("(1) Capture new student.");
        System.out.println("(2) Search for student.");
        System.out.println("(3) Delete a student.");
        System.out.println("(4) Print student report.");
        System.out.println("(5) Exit application");

        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        switch (choice) {
            case 1:
                captureNewStudent();
                break;
            case 2:
                searchForStudent();
                break;
            case 3:
                deleteStudent();
                break;
            case 4:
                printStudentReport();
                break;
            case 5:
                System.out.println("Exiting application.");
                System.exit(0);
                break;
            default:
                System.out.println("Invalid choice. Exiting application.");
                System.exit(0);
        }
    }

    static void captureNewStudent() {
        System.out.println("CAPTURE A NEW STUDENT");
        System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");

        String studentID;
        do {
            System.out.println("Enter the student ID:");
            studentID = scanner.nextLine();
            if (isStudentIDExists(studentID)) {
                System.out.println("Student with the same ID already exists. Please enter a different ID.");
            }
        } while (isStudentIDExists(studentID));

        System.out.println("Enter the student name:");
        String studentName = scanner.nextLine();
        int age = getValidAge();
        System.out.println("Enter the student email:");
        String email = scanner.nextLine();
        System.out.println("Enter the student course:");
        String course = scanner.nextLine();

        Student student = new Student(studentID, studentName, age, email, course);
        students.add(student);
        System.out.println("Student details have been successfully saved.");
        displayMenu();
    }

    private static int getValidAge() {
        int age = -1;
        boolean validAge = false;

        while (!validAge) {
            System.out.println("Enter the student age:");
            try {
                age = scanner.nextInt();
                scanner.nextLine(); // Consume newline character

                if (age >= 16) {
                    validAge = true;
                } else {
                    System.out.println("You have entered an incorrect student age!!");
                    System.out.println("Please re-enter the student age:");
                }
            } catch (InputMismatchException e) {
                scanner.nextLine(); // Clear the invalid input
                System.out.println("You have entered an incorrect student age!!");
                System.out.println("Please re-enter the student age:");
            }
        }

        return age;
    }

    private static boolean isStudentIDExists(String studentID) {
        for (Student student : students) {
            if (student.getStudentID().equalsIgnoreCase(studentID)) {
                return true;
            }
        }
        return false;
    }

    public static void searchForStudent() {
        System.out.println("Enter student ID to search:");
        String searchID = scanner.nextLine();

        for (Student student : students) {
            if (student.getStudentID().equalsIgnoreCase(searchID)) {
                System.out.println("---------------------------------------------------------------");
                System.out.println(student);
                System.out.println("--------------------------------------------------------------------");
                System.out.println("Enter 1 to launch menu or any other key to exit");
                displayMenu();
                return;
            }
        }

        System.out.println("--------------------------------------------------------------------");
        System.out.println("Student with the ID: " + searchID + " was not found!!!");
        System.out.println("--------------------------------------------------------------------");
        System.out.println("Enter 1 to launch menu or any other key to exit");
        displayMenu();
    }

    private static void deleteStudent() {
        System.out.println("Enter student ID to delete:");
        String deleteID = scanner.nextLine();

        for (Student student : students) {
            if (student.getStudentID().equalsIgnoreCase(deleteID)) {
                System.out.println("Are you sure you want to delete " + deleteID + " from the system? Yes(y) to delete?");
                String confirmDelete = scanner.nextLine().toLowerCase();

                if (confirmDelete.equals("y")) {
                    students.remove(student);
                    System.out.println("--------------------------------------------------");
                    System.out.println("Student with the ID " + deleteID + " was DELETED!!!");
                    System.out.println("--------------------------------------------------");
                } else {
                    System.out.println("Deletion canceled.");
                }

                displayMenu();
                return;
            }
        }

        System.out.println("Student not found.");
        displayMenu();
    }

    private static void printStudentReport() {
        if (students.isEmpty()) {
            System.out.println("No students to display.");
        } else {
            System.out.println("Student Report:");

            int studentCount = 1;
            for (Student student : students) {
                System.out.println("\nSTUDENT " + studentCount);
                System.out.println("-------------------------------------------------------------------------");
                System.out.println(student);
                System.out.println("-------------------------------------------------------------------------");
                studentCount++;
            }
        }
        
        System.out.println("Enter 1 to launch menu or any other key to exit");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        if (choice == 1) {
            displayMenu();
        } else {
            System.out.println("Exiting application.");
            System.exit(0);
        }
    }
}




