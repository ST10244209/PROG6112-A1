/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package prog6112.a1.question1;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import static org.junit.jupiter.api.Assertions.*;

public class StudentManagementAppTest {

    private final InputStream originalIn = System.in;
    private ByteArrayInputStream testIn;
    private ArrayList<Student> students;

    // Define outContent to capture standard output
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

    @BeforeEach
    public void setUp() {
        students = new ArrayList<>();
        testIn = new ByteArrayInputStream("1\nS12345\nSebastian naidoo\n20\nsebast@gmail.com\nComputer Science\n5\n".getBytes());
        System.setIn(testIn);

        // Redirect standard output to outContent
        System.setOut(new PrintStream(outContent));
    }

    @Test
    public void TestSaveStudent() {
        StudentManagementApp.students = students; // Set the ArrayList to the test ArrayList
        StudentManagementApp.captureNewStudent();

        assertEquals(1, students.size());
        assertEquals("S12345", students.get(0).getStudentID());
        assertEquals("Sebastian naidoo", students.get(0).getStudentName());
        assertEquals(20, students.get(0).getAge());
        assertEquals("sebast@gmail.com", students.get(0).getEmail());
        assertEquals("Computer Science", students.get(0).getCourse());
    }

    @Test
    public void TestSearchStudent() {
        StudentManagementApp.students = students; // Set the ArrayList to the test ArrayList
        students.add(new Student("S12345", "Sebastian naidoo", 20, "sebast@gmail.com", "Computer Science"));

        // Redirect the standard input to provide the search ID
        ByteArrayInputStream searchTestIn = new ByteArrayInputStream("2\nS12345\n5\n".getBytes());
        System.setIn(searchTestIn);

        // Test the search functionality
        StudentManagementApp.searchForStudent();

        // Capture the console output and assert the expected result
        String consoleOutput = outContent.toString();
        assertTrue(consoleOutput.contains("STUDENT ID: S12345"));
        assertTrue(consoleOutput.contains("STUDENT NAME: John Doe"));
        assertTrue(consoleOutput.contains("STUDENT AGE: 20"));
        assertTrue(consoleOutput.contains("STUDENT EMAIL: john@example.com"));
        assertTrue(consoleOutput.contains("STUDENT COURSE: Computer Science"));
    }

    @Test
    public void TestSearchStudent_StudentNotFound() {
        StudentManagementApp.students = students; // Set the ArrayList to the test ArrayList

        // Redirect the standard input to provide an invalid search ID
        ByteArrayInputStream searchTestIn = new ByteArrayInputStream("2\nS54321\n5\n".getBytes());
        System.setIn(searchTestIn);

        // Test the search functionality for a student that doesn't exist
        StudentManagementApp.searchForStudent();

        // Capture the console output and assert the expected result
        String consoleOutput = outContent.toString();
        assertTrue(consoleOutput.contains("Student with the ID: S54321 was not found"));
    }

    
}


