/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package prog6112.a1.question1;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class StudentTest {

    @Test
    public void testStudentConstructorAndGetters() {
        Student student = new Student("S12345", "John Doe", 20, "john@example.com", "Computer Science");
        
        assertEquals("S12345", student.getStudentID());
        assertEquals("Sebastian naidoo", student.getStudentName());
        assertEquals(20, student.getAge());
        assertEquals("sebast@gmail.com", student.getEmail());
        assertEquals("Computer Science", student.getCourse());
    }

    @Test
    public void testStudentToString() {
        Student student = new Student("S12345", "John Doe", 20, "john@example.com", "Computer Science");
        String expected = "STUDENT ID: S12345\n" +
                          "STUDENT NAME: Sebastian naidoo\n" +
                          "STUDENT AGE: 20\n" +
                          "STUDENT EMAIL: sebast@gmail.com\n" +
                          "STUDENT COURSE: Computer Science";
        assertEquals(expected, student.toString());
    }
}

